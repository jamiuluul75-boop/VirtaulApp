package top.niunaijun.blackbox.core;

import android.util.Log;
import top.niunaijun.blackbox.app.BActivityThread;

/**
 * Routes native calls to the runtime owned by the active virtual room.
 * Ruang 1 (userId 0 / MLBB)  → blackbox.so
 * Ruang 2 (userId 1 / MCGG)  → blackbox_mcgg.so
 *
 * Library dimuat secara conditional agar proses tiap ruang benar-benar terpisah.
 */
public final class NativeCoreBridge {
    private static final String TAG = "NativeCoreBridge";

    private static volatile boolean sLoaded = false;
    private static volatile boolean sIsMcgg = false;

    private NativeCoreBridge() {}

    private static boolean isMcgg() {
        return BActivityThread.getUserId() == 1;
    }

    /** Load only the native runtime that belongs to the current room. */
    private static synchronized void ensureLoaded() {
        if (sLoaded) return;

        sIsMcgg = isMcgg();
        try {
            if (sIsMcgg) {
                System.loadLibrary("blackbox_mcgg");
                Log.i(TAG, "Loaded dedicated MCGG native runtime → blackbox_mcgg (Ruang 2)");
            } else {
                System.loadLibrary("blackbox");
                Log.i(TAG, "Loaded MLBB native runtime → blackbox (Ruang 1)");
            }
            sLoaded = true;
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load native library for room userId=" + BActivityThread.getUserId(), e);
            throw e;
        }
    }

    public static void init(int apiLevel) {
        ensureLoaded();
        if (sIsMcgg) NevitecoreMcgg.init(apiLevel);
        else NativeCore.init(apiLevel);
    }

    public static void enableIO() {
        ensureLoaded();
        if (sIsMcgg) NevitecoreMcgg.enableIO();
        else NativeCore.enableIO();
    }

    public static void addIORule(String targetPath, String relocatePath) {
        ensureLoaded();
        if (sIsMcgg) NevitecoreMcgg.addIORule(targetPath, relocatePath);
        else NativeCore.addIORule(targetPath, relocatePath);
    }

    public static void hideXposed() {
        ensureLoaded();
        if (sIsMcgg) NevitecoreMcgg.hideXposed();
        else NativeCore.hideXposed();
    }

    public static boolean disableHiddenApi() {
        ensureLoaded();
        return sIsMcgg ? NevitecoreMcgg.disableHiddenApi() : NativeCore.disableHiddenApi();
    }

    public static boolean disableResourceLoading() {
        ensureLoaded();
        return sIsMcgg ? NevitecoreMcgg.disableResourceLoading() : NativeCore.disableResourceLoading();
    }
}
